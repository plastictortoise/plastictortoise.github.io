import{l as o,a as r}from"../chunks/CDH1-5uV.js";export{o as load_css,r as start};
